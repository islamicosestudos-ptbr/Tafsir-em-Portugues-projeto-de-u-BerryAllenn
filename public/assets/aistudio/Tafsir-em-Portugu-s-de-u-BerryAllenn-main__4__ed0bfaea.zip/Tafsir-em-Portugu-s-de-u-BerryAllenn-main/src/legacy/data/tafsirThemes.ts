// FP-20261029-TAFSIR-7867495988FE · wz:19df5f8e · WAZLA / u/BerryAllenn
import { ALL_SURAHS } from "./quranSurahs";
import { QuranPassageReference, QuranTheme, QuranThemeCategory } from "../types/quran";

/**
 * Biblioteca temática inicial: 16 categorias e 64 temas editoriais.
 * As referências são armazenadas uma única vez no registro canônico abaixo;
 * cada tema mantém apenas os IDs das passagens com as quais se relaciona.
 * Não são armazenados textos árabes, traduções ou trechos de tafsir aqui:
 * a leitura integral continua sendo fornecida pelo leitor e pelas fontes do app.
 */
export const QURAN_THEME_CATEGORIES: QuranThemeCategory[] = [
  {
    id: "allah-atributos",
    title: "Allah e os atributos divinos",
    description: "A unicidade, os nomes, a misericórdia e o poder do Criador.",
    iconName: "Sun",
  },
  {
    id: "fe-vida-espiritual",
    title: "Fé e vida espiritual",
    description: "As qualidades da fé e a formação da consciência espiritual.",
    iconName: "Heart",
  },
  {
    id: "alcorao-revelacao",
    title: "O Alcorão e a revelação",
    description: "Orientação, reflexão, conhecimento e sabedoria revelada.",
    iconName: "BookOpen",
  },
  {
    id: "adoracao-praticas",
    title: "Adoração e práticas religiosas",
    description: "A oração, o jejum, a caridade, a peregrinação e a devoção.",
    iconName: "Moon",
  },
  {
    id: "etica-carater",
    title: "Ética e caráter",
    description: "Princípios de conduta, justiça pessoal e aperfeiçoamento do caráter.",
    iconName: "Scale",
  },
  {
    id: "sociedade-direitos",
    title: "Sociedade, direitos e justiça",
    description: "Dignidade, proteção, solidariedade e responsabilidade coletiva.",
    iconName: "Users",
  },
  {
    id: "familia-relacoes",
    title: "Família e relações humanas",
    description: "Vínculos familiares, casamento, cuidado e parentesco.",
    iconName: "House",
  },
  {
    id: "provacoes-interior",
    title: "Provações e vida interior",
    description: "Paciência, esperança, lembrança de Allah e firmeza interior.",
    iconName: "ShieldCheck",
  },
  {
    id: "arrependimento-transformacao",
    title: "Arrependimento e transformação",
    description: "Retorno a Allah, perdão e mudança consciente de conduta.",
    iconName: "RefreshCw",
  },
  {
    id: "riqueza-trabalho",
    title: "Riqueza, trabalho e sustento",
    description: "Provisão, ética econômica, riqueza e responsabilidade material.",
    iconName: "Wallet",
  },
  {
    id: "profetas-mensageiros",
    title: "Profetas e mensageiros",
    description: "As missões proféticas e as lições de suas histórias.",
    iconName: "UserRound",
  },
  {
    id: "criacao-natureza",
    title: "Criação e sinais da natureza",
    description: "O universo, a vida e a diversidade como sinais para reflexão.",
    iconName: "Leaf",
  },
  {
    id: "historia-povos",
    title: "História e povos anteriores",
    description: "Narrativas corânicas e consequências das escolhas coletivas.",
    iconName: "Landmark",
  },
  {
    id: "conflito-paz",
    title: "Conflito, paz e convivência",
    description: "Paz, justiça, defesa e limites nas relações entre comunidades.",
    iconName: "Handshake",
  },
  {
    id: "morte-juizo",
    title: "Morte, ressurreição e Juízo Final",
    description: "A finitude, o retorno à vida e a prestação de contas.",
    iconName: "Hourglass",
  },
  {
    id: "paraiso-inferno-futuro",
    title: "Paraíso, Inferno e vida futura",
    description: "As realidades da Outra Vida e o destino das ações humanas.",
    iconName: "Flame",
  },
];

interface ThemeSeed extends Omit<QuranTheme, "addedOrder"> {
  passageIds: string[];
}

const THEME_SEEDS: ThemeSeed[] = [
  // 1. Allah e os atributos divinos
  {
    id: "tawhid-atributos",
    categoryId: "allah-atributos",
    title: "A unicidade de Allah (Tawhid)",
    description: "A afirmação de que Allah é Único, sem associado, semelhante ou dependente.",
    introduction:
      "Estude as passagens que afirmam a unicidade divina e a soberania exclusiva de Allah. Leia cada trecho em seu contexto, observando como o Alcorão rejeita a associação de parceiros a Ele.",
    keywords: ["tawhid", "unicidade", "monoteísmo", "shirk", "Allah", "divindade"],
    editorialFeatured: true,
    passageIds: ["112:1-4", "2:163", "6:102-103", "21:22", "59:22-24", "2:255"],
    reflectionQuestion:
      "Que implicações práticas a unicidade de Allah traz para a adoração e para as decisões cotidianas?",
  },
  {
    id: "nomes-mais-belos",
    categoryId: "allah-atributos",
    title: "Os Nomes Mais Belos de Allah",
    description: "A contemplação dos Nomes divinos e de seus significados no Alcorão.",
    introduction:
      "As passagens selecionadas apresentam os Nomes e atributos de Allah em diferentes contextos. A leitura deve respeitar o texto revelado, sem atribuir aos Nomes significados que não estejam fundamentados nas fontes utilizadas pelo aplicativo.",
    keywords: ["Asma ul Husna", "nomes", "atributos", "Al-Rahman", "Al-Rahim"],
    passageIds: ["7:180", "17:110", "20:8", "59:22-24", "1:1-4", "6:102-103"],
  },
  {
    id: "misericordia-divina",
    categoryId: "allah-atributos",
    title: "A misericórdia divina",
    description: "A amplitude da misericórdia de Allah e seus efeitos sobre a criação.",
    introduction:
      "Reúna as passagens que tratam da misericórdia como atributo divino, promessa e fundamento da esperança. A advertência e a promessa devem ser lidas em conjunto, sem transformar a misericórdia em licença para ignorar a responsabilidade moral.",
    keywords: ["misericórdia", "rahma", "perdão", "esperança", "compaixão"],
    editorialFeatured: true,
    passageIds: ["7:156", "39:53", "21:107", "40:7", "6:12", "12:87", "42:28"],
    reflectionQuestion:
      "Como a esperança na misericórdia pode coexistir com a responsabilidade por corrigir os próprios atos?",
  },
  {
    id: "conhecimento-e-poder-divinos",
    categoryId: "allah-atributos",
    title: "O conhecimento e o poder de Allah",
    description: "A ciência abrangente de Allah e seu domínio sobre toda a criação.",
    introduction:
      "As referências abordam o conhecimento divino, a criação e o domínio de Allah sobre aquilo que é manifesto e oculto. Observe os diferentes argumentos e imagens empregados nos trechos.",
    keywords: ["conhecimento", "poder", "onisciência", "criação", "soberania"],
    passageIds: ["2:255", "57:4", "6:59", "65:12", "31:34", "59:22-24", "3:190-191"],
  },

  // 2. Fé e vida espiritual
  {
    id: "sinais-dos-crentes",
    categoryId: "fe-vida-espiritual",
    title: "Os sinais dos verdadeiros crentes",
    description: "Características da fé manifestadas na consciência, na adoração e na conduta.",
    introduction:
      "Estas passagens descrevem qualidades associadas aos crentes. Elas permitem comparar a afirmação verbal da fé com seus sinais concretos, sem reduzir a vida espiritual a uma lista mecânica de comportamentos.",
    keywords: ["iman", "crentes", "fé", "oração", "conduta"],
    editorialFeatured: true,
    passageIds: ["8:2-4", "23:1-11", "49:15", "9:71", "70:22-35", "2:177", "103:1-3"],
  },
  {
    id: "taqwa-consciencia-de-allah",
    categoryId: "fe-vida-espiritual",
    title: "A consciência de Allah (Taqwa)",
    description: "A consciência de Allah como orientação para escolhas e responsabilidades.",
    introduction:
      "O taqwa aparece ligado à preparação espiritual, à dignidade diante de Allah e à observância de limites. A leitura comparada ajuda a distinguir consciência de Allah de uma simples aparência externa de religiosidade.",
    keywords: ["taqwa", "temor reverente", "consciência", "piedade", "retidão"],
    passageIds: ["2:197", "49:13", "3:102", "59:18", "65:2-3", "8:29", "2:177"],
    reflectionQuestion:
      "Que decisão concreta poderia ser diferente quando tomada com consciência de Allah?",
  },
  {
    id: "sinceridade-na-adoracao",
    categoryId: "fe-vida-espiritual",
    title: "A sinceridade na adoração",
    description: "A orientação para dedicar a religião e os atos de culto exclusivamente a Allah.",
    introduction:
      "As passagens tratam da intenção, da dedicação religiosa e da rejeição de associações na adoração. Leia-as distinguindo o princípio corânico da sinceridade de comentários posteriores sobre suas aplicações.",
    keywords: ["ikhlas", "sinceridade", "intenção", "adoração", "exclusividade"],
    passageIds: ["98:5", "6:162-163", "39:2-3", "18:110", "76:8-9"],
  },
  {
    id: "confianca-em-allah-tawakkul",
    categoryId: "fe-vida-espiritual",
    title: "A confiança em Allah (Tawakkul)",
    description: "A confiança em Allah associada à decisão, à ação e à perseverança.",
    introduction:
      "O tawakkul é apresentado em contextos de decisão, dificuldade e incerteza. As passagens permitem estudar a confiança em Allah sem separá-la da responsabilidade humana e da ação adequada.",
    keywords: ["tawakkul", "confiança", "dependência", "decisão", "provisão"],
    passageIds: ["3:159", "65:3", "8:2", "14:11-12", "9:51"],
  },

  // 3. O Alcorão e a revelação
  {
    id: "alcorao-como-orientacao",
    categoryId: "alcorao-revelacao",
    title: "O Alcorão como orientação",
    description: "A função do Alcorão como orientação, esclarecimento e misericórdia.",
    introduction:
      "As referências apresentam diferentes dimensões da orientação corânica. Leia a passagem completa no leitor para observar a quem o trecho se dirige e quais consequências práticas associa à orientação.",
    keywords: ["Alcorão", "huda", "orientação", "revelação", "guia"],
    editorialFeatured: true,
    passageIds: ["2:2-5", "17:9", "10:57", "6:155", "41:44", "38:29"],
  },
  {
    id: "reflexao-sobre-versiculos",
    categoryId: "alcorao-revelacao",
    title: "A reflexão sobre os versículos",
    description: "O convite à leitura atenta, à reflexão e à consideração do significado revelado.",
    introduction:
      "Estas passagens questionam a leitura superficial e convidam à reflexão. O estudo pode observar os verbos, as perguntas e os argumentos empregados, sem substituir a análise linguística e o tafsir por impressões pessoais.",
    keywords: ["tadabbur", "reflexão", "versículos", "compreensão", "leitura"],
    passageIds: ["4:82", "47:24", "38:29", "23:68", "3:190-191", "2:164", "12:111"],
    reflectionQuestion:
      "Que elementos do próprio contexto ajudam a evitar uma interpretação isolada do versículo?",
  },
  {
    id: "busca-pelo-conhecimento",
    categoryId: "alcorao-revelacao",
    title: "A busca pelo conhecimento",
    description: "O valor do conhecimento, do aprendizado e da investigação responsável.",
    introduction:
      "As passagens abordam conhecimento, aprendizagem e distinção entre saber e não saber. Considere os contextos em que o conhecimento é elogiado e as responsabilidades que o acompanham.",
    keywords: ["ilm", "conhecimento", "aprendizagem", "estudo", "ciência"],
    passageIds: ["20:114", "39:9", "96:1-5", "58:11", "35:28", "3:190-191", "17:36"],
  },
  {
    id: "sabedoria-e-boa-instrucao",
    categoryId: "alcorao-revelacao",
    title: "A sabedoria e a boa instrução",
    description: "A sabedoria na orientação, no diálogo e na transmissão do conhecimento.",
    introduction:
      "Os trechos associam sabedoria a discernimento e a formas adequadas de instrução. A leitura deve considerar o público, o assunto e o contexto de cada orientação.",
    keywords: ["hikmah", "sabedoria", "instrução", "diálogo", "discernimento"],
    passageIds: ["16:125", "2:269", "17:36", "29:43", "12:111", "3:159"],
  },

  // 4. Adoração e práticas religiosas
  {
    id: "oracao-salat",
    categoryId: "adoracao-praticas",
    title: "A oração (Salat)",
    description: "A oração como prática de adoração, lembrança de Allah e disciplina espiritual.",
    introduction:
      "As referências contemplam a ordem da oração, seus efeitos e sua relação com a vida diária. O leitor deve consultar o texto integral e o tafsir para estudar as condições e os sentidos de cada passagem.",
    keywords: ["salat", "oração", "salah", "adoração", "purificação"],
    editorialFeatured: true,
    passageIds: ["2:43", "29:45", "11:114", "17:78", "23:1-2", "2:177"],
  },
  {
    id: "jejum-e-ramada",
    categoryId: "adoracao-praticas",
    title: "O jejum e o Ramadã",
    description: "A prescrição do jejum, o mês de Ramadã e suas orientações.",
    introduction:
      "O núcleo do estudo está nas passagens de Al-Baqarah que prescrevem e esclarecem o jejum. Os demais trechos ampliam o contexto espiritual da adoração e devem ser lidos sem confundir recomendações gerais com regras jurídicas específicas.",
    keywords: ["sawm", "jejum", "Ramadã", "Ramadan", "abstinência"],
    passageIds: ["2:183-187", "2:185", "2:186", "33:35", "97:1-5"],
  },
  {
    id: "caridade-e-zakat",
    categoryId: "adoracao-praticas",
    title: "A caridade e o Zakat",
    description:
      "A purificação da riqueza, a generosidade e os destinatários da caridade obrigatória.",
    introduction:
      "As passagens abrangem a multiplicação da recompensa pela caridade, a qualidade daquilo que é doado e os destinatários do Zakat. A distinção entre caridade voluntária e obrigação jurídica deve ser mantida no estudo.",
    keywords: ["zakat", "sadaqah", "caridade", "esmola", "doação"],
    passageIds: ["2:261-274", "9:60", "2:267", "9:103", "57:7", "76:8-9"],
  },
  {
    id: "hajj-e-casa-sagrada",
    categoryId: "adoracao-praticas",
    title: "O Hajj e a Casa Sagrada",
    description: "A peregrinação, seus ritos e a centralidade da Casa Sagrada.",
    introduction:
      "As referências apresentam instruções e marcos da peregrinação. A leitura integral ajuda a distinguir os ritos mencionados pelo Alcorão de detalhes jurídicos desenvolvidos nas fontes de fiqh.",
    keywords: ["Hajj", "peregrinação", "Kaaba", "Casa Sagrada", "Umrah"],
    passageIds: ["2:196-203", "22:27-29", "3:97", "2:158", "22:32"],
  },

  // 5. Ética e caráter
  {
    id: "etica-fraternidade",
    categoryId: "etica-carater",
    title: "A justiça e a equidade",
    description:
      "A obrigação de agir com justiça, mesmo quando isso contraria interesses pessoais.",
    introduction:
      "As passagens estabelecem a justiça como princípio que não deve ser subordinado a preferências, relações pessoais ou hostilidade. Compare as situações e os deveres apresentados em cada contexto.",
    keywords: ["justiça", "equidade", "adl", "testemunho", "imparcialidade"],
    editorialFeatured: true,
    passageIds: ["4:135", "5:8", "16:90", "17:35", "42:15", "2:177"],
    reflectionQuestion:
      "Em que situação a justiça exige contrariar o próprio interesse ou o interesse de pessoas próximas?",
  },
  {
    id: "honestidade-e-compromissos",
    categoryId: "etica-carater",
    title: "A honestidade e o cumprimento dos compromissos",
    description: "A veracidade, a confiança e o respeito aos acordos e às medidas justas.",
    introduction:
      "Os trechos relacionam a integridade pessoal ao cumprimento de compromissos e à honestidade nas transações. A leitura pode ser aplicada a relações privadas, profissionais e comerciais, respeitando o alcance de cada passagem.",
    keywords: ["honestidade", "promessas", "pactos", "medidas", "confiança"],
    passageIds: ["17:34-35", "83:1-3", "5:1", "8:27", "23:8", "2:177"],
  },
  {
    id: "controle-da-ira-e-perdao",
    categoryId: "etica-carater",
    title: "O controle da ira e o perdão",
    description: "O domínio da reação, a contenção da ira e a disposição para perdoar.",
    introduction:
      "Estas passagens tratam de contenção, perdão e resposta ao mal. A leitura comparada permite distinguir perdão, reconciliação e justiça, conceitos relacionados, mas não idênticos.",
    keywords: ["ira", "raiva", "perdão", "paciência", "autocontrole"],
    passageIds: ["3:134", "42:37", "24:22", "41:34", "42:40"],
  },
  {
    id: "humildade-e-rejeicao-da-arrogancia",
    categoryId: "etica-carater",
    title: "A humildade e a rejeição da arrogância",
    description: "A moderação na conduta e a rejeição da superioridade arrogante.",
    introduction:
      "As passagens oferecem orientações sobre postura, linguagem e relações com outras pessoas. Observe como a humildade é traduzida em atitudes concretas, e não apenas em uma declaração interior.",
    keywords: ["humildade", "arrogância", "modéstia", "orgulho", "conduta"],
    passageIds: ["31:18-19", "25:63", "17:37", "4:36", "49:11-12"],
  },

  // 6. Sociedade, direitos e justiça
  {
    id: "dignidade-humana",
    categoryId: "sociedade-direitos",
    title: "A dignidade humana",
    description: "A honra concedida aos seres humanos e a rejeição de hierarquias injustas.",
    introduction:
      "Os trechos tratam da dignidade humana, da origem comum e da diversidade entre povos. Leia as referências em seu contexto para identificar o fundamento e o alcance de cada afirmação.",
    keywords: ["dignidade", "humanidade", "origem", "diversidade", "direitos"],
    editorialFeatured: true,
    passageIds: ["17:70", "49:13", "95:4", "4:1", "5:32"],
  },
  {
    id: "reconciliacao-entre-pessoas",
    categoryId: "sociedade-direitos",
    title: "A reconciliação entre pessoas",
    description:
      "A resolução de conflitos, a conciliação e a preservação dos vínculos comunitários.",
    introduction:
      "As passagens orientam a mediação de conflitos e a restauração de relações. A reconciliação não elimina a exigência de justiça: os textos devem ser lidos em conjunto para compreender os limites e os deveres envolvidos.",
    keywords: ["reconciliação", "conciliação", "conflito", "comunidade", "mediação"],
    passageIds: ["49:9-10", "4:114", "8:1", "3:103", "42:40"],
  },
  {
    id: "cooperacao-no-bem",
    categoryId: "sociedade-direitos",
    title: "A cooperação no bem",
    description: "A colaboração para a retidão e a responsabilidade compartilhada.",
    introduction:
      "Os trechos relacionam a vida comunitária à cooperação, à solidariedade e à responsabilidade coletiva. A seleção distingue colaboração no bem de apoio indiscriminado a qualquer objetivo de um grupo.",
    keywords: ["cooperação", "solidariedade", "bem", "comunidade", "responsabilidade"],
    passageIds: ["5:2", "3:104", "9:71", "103:1-3", "2:177"],
  },
  {
    id: "protecao-orfaos-vulneraveis",
    categoryId: "sociedade-direitos",
    title: "A proteção dos órfãos e vulneráveis",
    description:
      "A proteção patrimonial, social e moral de pessoas em situação de vulnerabilidade.",
    introduction:
      "As passagens proíbem abusos e chamam atenção para a responsabilidade diante de pessoas vulneráveis. O estudo deve observar tanto as normas específicas sobre órfãos quanto a crítica à negligência social.",
    keywords: ["órfãos", "vulneráveis", "proteção", "pobreza", "amparo"],
    passageIds: ["4:2", "4:10", "93:9", "107:1-3", "2:220", "2:177", "76:8-9"],
  },

  // 7. Família e relações humanas
  {
    id: "bondade-para-com-os-pais",
    categoryId: "familia-relacoes",
    title: "A bondade para com os pais",
    description:
      "O dever de tratar os pais com respeito e bondade, dentro dos limites da obediência a Allah.",
    introduction:
      "As passagens articulam gratidão, cuidado e respeito aos pais. A referência a limites da obediência deve ser preservada: a bondade filial não significa obedecer a uma ordem que contrarie a orientação divina.",
    keywords: ["pais", "mãe", "pai", "bondade filial", "família"],
    editorialFeatured: true,
    passageIds: ["17:23-24", "31:14-15", "46:15", "29:8", "4:36"],
  },
  {
    id: "casamento-e-tranquilidade",
    categoryId: "familia-relacoes",
    title: "O casamento e a tranquilidade",
    description: "O casamento, a afeição e a misericórdia nas relações conjugais.",
    introduction:
      "As referências abordam a origem dos vínculos conjugais, a intimidade e a busca por tranquilidade. As passagens devem ser lidas em seu contexto, sem transformar uma síntese temática em parecer jurídico sobre casos específicos.",
    keywords: ["casamento", "matrimônio", "tranquilidade", "afeição", "misericórdia"],
    passageIds: ["30:21", "25:74", "2:187", "4:1", "24:32"],
  },
  {
    id: "responsabilidade-familiar-e-filhos",
    categoryId: "familia-relacoes",
    title: "A responsabilidade familiar e a educação dos filhos",
    description: "O cuidado, a orientação e a responsabilidade dos membros da família.",
    introduction:
      "Os textos selecionados tratam da proteção da família, da educação e das responsabilidades de cuidado. A orientação religiosa deve ser acompanhada de justiça e de atenção às necessidades concretas dos dependentes.",
    keywords: ["filhos", "educação", "responsabilidade", "criação", "família"],
    passageIds: ["66:6", "31:13-19", "20:132", "2:233", "17:31", "25:74"],
  },
  {
    id: "lacos-de-parentesco",
    categoryId: "familia-relacoes",
    title: "Os laços de parentesco",
    description: "A preservação dos vínculos familiares e os deveres decorrentes do parentesco.",
    introduction:
      "As referências relacionam os laços de parentesco à origem humana, à justiça e à responsabilidade. Compare os mandamentos e advertências para compreender a relevância social desses vínculos.",
    keywords: ["parentesco", "família extensa", "laços", "parentes", "relação"],
    passageIds: ["4:1", "47:22-23", "16:90", "8:75", "13:21", "17:23-24", "4:36"],
  },

  // 8. Provações e vida interior
  {
    id: "paciencia-consolo",
    categoryId: "provacoes-interior",
    title: "A paciência (Sabr)",
    description: "A perseverança diante das provações e a busca de auxílio por meio da paciência.",
    introduction:
      "As passagens descrevem paciência em circunstâncias distintas. A leitura permite estudar a perseverança como postura ativa de fé, sem confundi-la com passividade diante de injustiças ou problemas que exigem ação.",
    keywords: ["sabr", "paciência", "perseverança", "provação", "firmeza"],
    editorialFeatured: true,
    passageIds: ["2:153-157", "3:200", "16:127", "39:10", "11:115"],
    reflectionQuestion:
      "Qual é a diferença entre perseverar com firmeza e aceitar passivamente uma situação que pode ser corrigida?",
  },
  {
    id: "dificuldade-e-alivio",
    categoryId: "provacoes-interior",
    title: "A dificuldade e o alívio",
    description:
      "As passagens que relacionam a adversidade à capacidade e ao auxílio concedido por Allah.",
    introduction:
      "Os trechos abordam a dificuldade sob diferentes ângulos: promessa de alívio, limite da capacidade humana e prova. Evite tratar uma passagem isolada como garantia de que toda adversidade terminará imediatamente.",
    keywords: ["dificuldade", "alívio", "adversidade", "provação", "facilidade"],
    passageIds: ["94:5-6", "2:286", "65:7", "2:214", "2:155-157"],
  },
  {
    id: "lembranca-de-allah-tranquilidade",
    categoryId: "provacoes-interior",
    title: "A lembrança de Allah e a tranquilidade",
    description: "A lembrança de Allah como elemento central da vida espiritual.",
    introduction:
      "As referências ligam a lembrança de Allah à firmeza, à gratidão e à prática religiosa. O estudo pode considerar as diferentes formas de dhikr apresentadas pelo texto e seus contextos.",
    keywords: ["dhikr", "lembrança", "recordação", "tranquilidade", "coração"],
    passageIds: ["13:28", "2:152", "33:41-42", "8:45", "29:45"],
  },
  {
    id: "esperanca-na-misericordia",
    categoryId: "provacoes-interior",
    title: "A esperança na misericórdia divina",
    description: "A esperança diante do sofrimento, do erro e da incerteza.",
    introduction:
      "As passagens apresentam a esperança como resposta à aflição e ao erro. Leia também as advertências presentes nos contextos para manter unidos esperança, responsabilidade e confiança em Allah.",
    keywords: ["esperança", "misericórdia", "desespero", "aflição", "socorro"],
    passageIds: ["12:87", "39:53", "15:56", "41:49", "42:28", "7:156", "6:12"],
  },

  // 9. Arrependimento e transformação
  {
    id: "arrependimento-sincero",
    categoryId: "arrependimento-transformacao",
    title: "O arrependimento sincero",
    description: "O retorno consciente a Allah e o compromisso de abandonar o erro.",
    introduction:
      "As referências tratam do arrependimento e de suas condições espirituais e morais. O estudo deve diferenciar o arrependimento sincero de uma simples declaração sem mudança de direção.",
    keywords: ["tawbah", "arrependimento", "retorno", "pecado", "reforma"],
    editorialFeatured: true,
    passageIds: ["66:8", "4:17-18", "3:135", "2:222", "25:68-71", "39:53"],
  },
  {
    id: "perdao-e-transformacao-moral",
    categoryId: "arrependimento-transformacao",
    title: "O perdão e a transformação moral",
    description: "A relação entre perdão, correção dos atos e reconstrução da conduta.",
    introduction:
      "Os textos selecionados relacionam o perdão divino à transformação e à prática de boas ações. Leia as condições e os exemplos apresentados, sem atribuir ao perdão um sentido separado da responsabilidade.",
    keywords: ["perdão", "reforma", "transformação", "boas ações", "retidão"],
    passageIds: ["25:68-71", "42:25", "39:53", "8:29", "11:114", "3:135"],
  },
  {
    id: "mudanca-interior",
    categoryId: "arrependimento-transformacao",
    title: "A mudança interior",
    description: "A transformação pessoal e coletiva ligada às escolhas e disposições humanas.",
    introduction:
      "As passagens abordam mudança, autoconhecimento e responsabilidade. Observe quais condições são explicitamente mencionadas e evite transformar os textos em fórmulas simplistas de sucesso individual.",
    keywords: ["mudança", "transformação", "autoconhecimento", "reforma", "intenção"],
    passageIds: ["13:11", "91:7-10", "59:18", "53:39", "76:3", "3:135"],
  },
  {
    id: "proibicao-do-desespero",
    categoryId: "arrependimento-transformacao",
    title: "A proibição de desesperar da misericórdia de Allah",
    description: "A advertência contra o desespero e o chamado ao retorno a Allah.",
    introduction:
      "Estas referências destacam a esperança na misericórdia divina mesmo diante de erros graves. A leitura deve considerar o contexto de cada advertência e a necessidade de arrependimento e correção.",
    keywords: ["desespero", "misericórdia", "perdão", "esperança", "retorno"],
    passageIds: ["39:53", "12:87", "15:56", "29:23", "42:28"],
  },

  // 10. Riqueza, trabalho e sustento
  {
    id: "sustento-concedido-por-allah",
    categoryId: "riqueza-trabalho",
    title: "O sustento concedido por Allah",
    description: "A provisão, o trabalho e a confiança em Allah diante das necessidades materiais.",
    introduction:
      "As passagens apresentam a provisão como parte da ordem criada por Allah e orientam a ação humana. O estudo deve evitar leituras que prometam riqueza automática ou dispensem esforço e responsabilidade.",
    keywords: ["rizq", "sustento", "provisão", "trabalho", "confiança"],
    editorialFeatured: true,
    passageIds: ["11:6", "29:60", "67:15", "62:10", "2:172", "16:10-11", "39:21"],
  },
  {
    id: "etica-medidas-transacoes",
    categoryId: "riqueza-trabalho",
    title: "A ética nas medidas e transações",
    description: "A honestidade comercial e a proibição de fraude nas medidas e nos pesos.",
    introduction:
      "Os textos condenam a fraude e exigem integridade nas transações. A aplicação a contratos e práticas econômicas atuais exige análise adicional de contexto e jurisprudência, não apenas analogia superficial.",
    keywords: ["comércio", "medidas", "pesos", "fraude", "transações"],
    passageIds: ["83:1-3", "6:152", "17:35", "55:9", "7:85"],
  },
  {
    id: "proibicao-da-usura-riba",
    categoryId: "riqueza-trabalho",
    title: "A proibição da usura (Riba)",
    description: "As advertências corânicas sobre riba e as orientações relativas às transações.",
    introduction:
      "O núcleo do estudo está nas passagens que tratam diretamente de riba. Os demais trechos devem ser lidos como contexto complementar; a classificação de produtos financeiros contemporâneos requer estudo jurídico especializado.",
    keywords: ["riba", "usura", "juros", "finanças", "economia islâmica"],
    passageIds: ["2:275-279", "3:130", "30:39", "4:161", "2:276"],
  },
  {
    id: "riqueza-como-prova",
    categoryId: "riqueza-trabalho",
    title: "A riqueza como prova",
    description: "A riqueza e os bens como responsabilidade, teste e fonte de prestação de contas.",
    introduction:
      "As referências apresentam bens e riqueza como elementos de prova, não como medida automática de mérito. A leitura pode relacionar posse, generosidade, prioridades e responsabilidade perante Allah.",
    keywords: ["riqueza", "bens", "prova", "dinheiro", "responsabilidade"],
    passageIds: ["8:28", "64:15", "3:186", "18:46", "9:34-35", "2:261-274", "57:7"],
  },

  // 11. Profetas e mensageiros
  {
    id: "ibrahim-submissao-allah",
    categoryId: "profetas-mensageiros",
    title: "Ibrahim e a submissão a Allah",
    description: "A fé, as provas e a submissão de Ibrahim a Allah.",
    introduction:
      "As passagens mostram momentos distintos da vida de Ibrahim: sua busca, suas provas e sua disposição de obedecer a Allah. A leitura em sequência ajuda a acompanhar a construção da narrativa.",
    keywords: ["Ibrahim", "Abraão", "submissão", "monoteísmo", "profeta"],
    editorialFeatured: true,
    passageIds: ["2:124-132", "6:74-79", "21:51-73", "37:99-111", "60:4"],
  },
  {
    id: "musa-confronto-farao",
    categoryId: "profetas-mensageiros",
    title: "Musa e o confronto com Faraó",
    description: "A missão de Musa diante da tirania de Faraó e a libertação dos oprimidos.",
    introduction:
      "As referências acompanham a missão de Musa, o confronto com Faraó e os sinais apresentados ao seu povo. Observe as diferenças entre os relatos e o papel desempenhado por cada episódio.",
    keywords: ["Musa", "Moisés", "Faraó", "tirania", "Êxodo"],
    passageIds: ["20:9-79", "28:3-6", "7:103-137", "26:10-68", "79:15-26"],
  },
  {
    id: "yusuf-adversidade-perdao",
    categoryId: "profetas-mensageiros",
    title: "Yusuf, a adversidade e o perdão",
    description: "A narrativa de Yusuf: provação, integridade, paciência e reconciliação.",
    introduction:
      "A Surata Yusuf apresenta uma narrativa contínua sobre perda, injustiça, tentação, poder e perdão. As passagens foram divididas em etapas de leitura para facilitar o estudo sem retirar os episódios de seu encadeamento.",
    keywords: ["Yusuf", "José", "adversidade", "perdão", "sonho"],
    passageIds: ["12:4-18", "12:23-35", "12:50-57", "12:86-101", "12:90-92", "12:111"],
  },
  {
    id: "muhammad-como-mensageiro",
    categoryId: "profetas-mensageiros",
    title: "Muhammad como mensageiro",
    description: "A missão profética de Muhammad e as características de sua comunidade.",
    introduction:
      "Os trechos apresentam a condição de mensageiro, a missão de misericórdia e a descrição dos que o acompanham. Para aprofundamento biográfico, a leitura deve ser complementada pelas fontes de Sirah disponíveis.",
    keywords: ["Muhammad", "Maomé", "mensageiro", "profeta", "Sirah"],
    passageIds: ["33:40", "48:29", "21:107", "9:128", "68:4"],
  },

  // 12. Criação e sinais da natureza
  {
    id: "criacao-ceus-e-terra",
    categoryId: "criacao-natureza",
    title: "A criação dos céus e da Terra",
    description: "A criação e a ordem do universo como sinais para quem reflete.",
    introduction:
      "As passagens convocam à observação dos céus, da Terra e da ordem da criação. O objetivo do estudo é identificar o argumento corânico em seu contexto, sem atribuir ao texto afirmações científicas que ele não faz.",
    keywords: ["criação", "céus", "Terra", "universo", "sinais"],
    editorialFeatured: true,
    passageIds: ["3:190-191", "2:164", "41:53", "67:3-4", "45:3-5", "30:22"],
  },
  {
    id: "agua-e-vida",
    categoryId: "criacao-natureza",
    title: "A água e a vida",
    description: "A água como elemento essencial à vida e sinal da criação.",
    introduction:
      "Os trechos relacionam água, chuva, vegetação e vida. Leia as referências por inteiro e considere a função da água em cada argumento, sem forçar equivalências com teorias científicas modernas.",
    keywords: ["água", "chuva", "vida", "vegetação", "criação"],
    passageIds: ["21:30", "24:45", "25:48-49", "16:10-11", "39:21"],
  },
  {
    id: "animais-como-sinais",
    categoryId: "criacao-natureza",
    title: "Os animais como sinais",
    description: "Os animais, seus modos de vida e sua utilidade como sinais da criação.",
    introduction:
      "As passagens mencionam animais em contextos de reflexão sobre a criação, a subsistência e a organização da vida. O estudo pode observar a diversidade de exemplos apresentados no texto.",
    keywords: ["animais", "fauna", "criação", "sinais", "natureza"],
    passageIds: ["16:5-8", "24:41", "6:38", "16:68-69", "40:79-80"],
  },
  {
    id: "diversidade-da-criacao",
    categoryId: "criacao-natureza",
    title: "A diversidade da criação",
    description: "A diversidade de línguas, cores, povos e formas de vida.",
    introduction:
      "Os trechos apontam a diversidade como parte dos sinais da criação. A leitura aproxima diferenças humanas e naturais sem convertê-las em hierarquias de valor não sustentadas pelo texto.",
    keywords: ["diversidade", "línguas", "cores", "povos", "natureza"],
    passageIds: ["30:22", "49:13", "35:27-28", "16:72", "42:8"],
  },

  // 13. História e povos anteriores
  {
    id: "povo-de-nuh",
    categoryId: "historia-povos",
    title: "O povo de Nuh (Noé)",
    description: "A missão de Nuh, a rejeição de seu povo e o desfecho da narrativa.",
    introduction:
      "As referências apresentam episódios da missão de Nuh em diferentes suratas. Compare os relatos para compreender os elementos recorrentes e os detalhes próprios de cada passagem.",
    keywords: ["Nuh", "Noé", "dilúvio", "povo", "profeta"],
    editorialFeatured: true,
    passageIds: ["71:1-28", "11:25-49", "23:23-30", "26:105-122", "54:9-17"],
  },
  {
    id: "ad-e-thamud",
    categoryId: "historia-povos",
    title: "Os povos de 'Ad e Thamud",
    description: "As advertências dirigidas a 'Ad e Thamud e as consequências de sua rejeição.",
    introduction:
      "As passagens reúnem relatos sobre os dois povos e seus mensageiros. Observe a sequência entre advertência, resposta coletiva e consequência, evitando misturar detalhes de narrativas distintas.",
    keywords: ["Ad", "Thamud", "Hud", "Salih", "povos antigos"],
    passageIds: ["7:65-79", "11:50-68", "26:123-159", "41:13-18", "69:4-8", "14:9"],
  },
  {
    id: "qarun-e-a-riqueza",
    categoryId: "historia-povos",
    title: "Qarun e a riqueza",
    description: "A riqueza de Qarun, sua arrogância e a advertência dirigida à sociedade.",
    introduction:
      "A narrativa de Qarun examina a relação entre riqueza, presunção e responsabilidade. As passagens complementares ajudam a contextualizar a narrativa e a crítica à fascinação pela riqueza.",
    keywords: ["Qarun", "riqueza", "arrogância", "poder", "Musa"],
    passageIds: ["28:76-82", "29:39", "40:23-24", "28:83-84", "57:20"],
  },
  {
    id: "licoes-dos-povos-anteriores",
    categoryId: "historia-povos",
    title: "As lições dos povos anteriores",
    description: "O estudo da história como advertência e reflexão sobre escolhas coletivas.",
    introduction:
      "As referências convidam a observar os vestígios e os relatos dos povos anteriores. O foco está na reflexão sobre causas e consequências, sem presumir que toda situação histórica atual corresponda diretamente a um episódio antigo.",
    keywords: ["história", "povos anteriores", "lições", "narrativas", "advertência"],
    passageIds: ["12:111", "30:9", "7:176", "14:9", "22:45-46", "54:9-17"],
  },

  // 14. Conflito, paz e convivência
  {
    id: "inclinacao-a-paz",
    categoryId: "conflito-paz",
    title: "A inclinação à paz",
    description: "A orientação para aceitar a paz e buscar a resolução de conflitos.",
    introduction:
      "As referências tratam de paz, cessação de hostilidades e reconciliação. O contexto de cada passagem é essencial para compreender quando se trata de uma proposta de paz, de uma trégua ou de uma mediação comunitária.",
    keywords: ["paz", "trégua", "reconciliação", "convivência", "hostilidade"],
    editorialFeatured: true,
    passageIds: ["8:61", "4:90", "60:8-9", "49:9-10", "8:1", "42:40"],
  },
  {
    id: "justica-diante-da-hostilidade",
    categoryId: "conflito-paz",
    title: "A justiça mesmo diante da hostilidade",
    description: "A exigência de justiça e imparcialidade mesmo diante de adversários.",
    introduction:
      "As passagens recusam que a hostilidade seja justificativa para abandonar a justiça. A aplicação a conflitos contemporâneos exige primeiro identificar o contexto e os sujeitos a que cada texto se refere.",
    keywords: ["justiça", "hostilidade", "adversários", "imparcialidade", "equidade"],
    passageIds: ["5:8", "4:135", "60:8", "42:40", "16:90", "49:9-10"],
  },
  {
    id: "defesa-e-limites-do-combate",
    categoryId: "conflito-paz",
    title: "A defesa e os limites do combate",
    description: "As referências sobre defesa, limites e proteção em situações de conflito.",
    introduction:
      "Estas passagens precisam ser estudadas com atenção ao contexto histórico e às condições mencionadas pelo próprio texto. Não constituem autorização genérica para violência individual ou para ações fora dos limites estabelecidos.",
    keywords: ["combate", "defesa", "limites", "guerra", "hostilidade"],
    passageIds: ["2:190", "22:39-40", "2:193", "8:61", "9:6", "4:90"],
  },
  {
    id: "bondade-com-nao-combatentes",
    categoryId: "conflito-paz",
    title: "A bondade com quem não combate",
    description:
      "A justiça e a bondade nas relações com pessoas que não participam de hostilidades.",
    introduction:
      "Os trechos orientam a conduta diante de pessoas que não combatem os muçulmanos e abordam proteção e segurança. Leia as condições expressas nos versículos; não generalize o texto para situações que ele não descreve.",
    keywords: ["não combatentes", "bondade", "proteção", "convivência", "segurança"],
    passageIds: ["60:8-9", "4:90", "9:6", "5:8", "2:256"],
  },

  // 15. Morte, ressurreição e Juízo Final
  {
    id: "certeza-da-morte",
    categoryId: "morte-juizo",
    title: "A certeza da morte",
    description: "A inevitabilidade da morte e o retorno de todas as pessoas a Allah.",
    introduction:
      "As referências afirmam a inevitabilidade da morte e a impossibilidade de evitá-la por meios humanos. A leitura permite estudar como o Alcorão relaciona finitude e responsabilidade.",
    keywords: ["morte", "finitude", "retorno", "vida", "destino"],
    editorialFeatured: true,
    passageIds: ["3:185", "29:57", "62:8", "21:35", "4:78"],
  },
  {
    id: "ressurreicao",
    categoryId: "morte-juizo",
    title: "A ressurreição",
    description: "A reunião após a morte e a restauração da vida para a prestação de contas.",
    introduction:
      "Os trechos apresentam imagens e argumentos corânicos sobre a ressurreição. Leia as passagens integralmente para compreender a progressão do argumento e os questionamentos aos que negam o retorno à vida.",
    keywords: ["ressurreição", "retorno à vida", "baath", "sepulturas", "recriação"],
    passageIds: ["36:51-54", "75:1-15", "22:5-7", "17:49-51", "50:3-4", "99:6-8"],
  },
  {
    id: "dia-do-juizo",
    categoryId: "morte-juizo",
    title: "O Dia do Juízo",
    description: "A prestação de contas e a exposição das ações no Dia do Juízo.",
    introduction:
      "As passagens descrevem cenas do Juízo e a diferença entre os resultados das ações. A leitura deve respeitar as imagens e os termos próprios de cada surata, sem fundir descrições diferentes em uma única narrativa.",
    keywords: ["Juízo Final", "Qiyamah", "julgamento", "prestação de contas", "Dia"],
    passageIds: ["99:6-8", "101:6-11", "82:1-5", "84:7-12", "17:13-14", "21:47"],
  },
  {
    id: "responsabilidade-pelas-acoes",
    categoryId: "morte-juizo",
    title: "A responsabilidade pelas ações",
    description: "O registro das ações e a responsabilidade individual diante de Allah.",
    introduction:
      "Os trechos enfatizam que as ações humanas não são esquecidas e que cada pessoa será confrontada com seu registro. O estudo pode relacionar responsabilidade, intenção e consequências, observando o texto completo.",
    keywords: ["ações", "responsabilidade", "registro", "prestação de contas", "individual"],
    passageIds: ["17:13-14", "18:49", "36:65", "75:13-15", "99:7-8", "101:6-11"],
  },

  // 16. Paraíso, Inferno e vida futura
  {
    id: "descricao-do-paraiso",
    categoryId: "paraiso-inferno-futuro",
    title: "A descrição do Paraíso",
    description: "As imagens corânicas do Paraíso e as recompensas destinadas aos justos.",
    introduction:
      "As passagens apresentam descrições do Paraíso em diferentes suratas e registros. Leia cada trecho no contexto para distinguir imagens de recompensa, qualidades dos habitantes e promessas específicas.",
    keywords: ["Paraíso", "Jannah", "recompensa", "vida futura", "jardins"],
    editorialFeatured: true,
    passageIds: ["47:15", "55:46-78", "76:11-22", "56:10-40", "13:23-24", "3:14-15"],
  },
  {
    id: "descricao-do-inferno",
    categoryId: "paraiso-inferno-futuro",
    title: "A descrição do Inferno",
    description: "As advertências corânicas sobre o Inferno e as consequências da rejeição.",
    introduction:
      "Os trechos apresentam advertências e descrições do Inferno. A leitura deve manter o contexto das advertências e evitar usar uma passagem isolada para declarar o destino de pessoas específicas.",
    keywords: ["Inferno", "Jahannam", "Fogo", "advertência", "castigo"],
    passageIds: ["4:56", "67:6-11", "14:16-17", "44:43-50", "101:8-11"],
  },
  {
    id: "balanca-das-acoes",
    categoryId: "paraiso-inferno-futuro",
    title: "A balança das ações",
    description: "A pesagem das ações e a justiça perfeita no julgamento.",
    introduction:
      "As referências tratam da balança, do peso das obras e dos resultados do julgamento. Observe as diferentes formulações antes de concluir que todas descrevem o mesmo aspecto de uma única cena.",
    keywords: ["balança", "Mizan", "ações", "julgamento", "justiça"],
    passageIds: ["21:47", "7:8-9", "23:102-103", "99:7-8", "101:6-11", "18:49"],
  },
  {
    id: "vida-terrena-e-vida-futura",
    categoryId: "paraiso-inferno-futuro",
    title: "A vida terrena e a vida futura",
    description: "A comparação entre a vida presente e a Outra Vida e a definição de prioridades.",
    introduction:
      "Os textos comparam a vida terrena à vida futura e questionam prioridades humanas. A leitura deve evitar a conclusão de que a vida presente não possui responsabilidades: o próprio Alcorão orienta como agir nela.",
    keywords: ["Dunya", "Akhirah", "vida terrena", "Outra Vida", "prioridades"],
    passageIds: ["29:64", "87:16-17", "3:14-15", "57:20", "42:20", "18:46", "3:185"],
  },
];

export const QURAN_THEMES: QuranTheme[] = THEME_SEEDS.map((theme, index) => ({
  ...theme,
  addedOrder: index + 1,
  editorialReviewStatus: "pending",
}));

function normalizePassageReference(reference: string): QuranPassageReference | null {
  const match = /^(\d{1,3}):(\d{1,3})(?:-(\d{1,3}))?$/.exec(reference.trim().replace(/[–—]/g, "-"));
  if (!match) return null;
  const surahNumber = Number(match[1]);
  const startAyah = Number(match[2]);
  const endAyah = match[3] ? Number(match[3]) : undefined;
  const surah = ALL_SURAHS.find((item) => item.number === surahNumber);
  if (!surah || startAyah < 1 || (endAyah !== undefined && endAyah < startAyah)) return null;
  if (startAyah > surah.totalAyahs || (endAyah !== undefined && endAyah > surah.totalAyahs))
    return null;
  return {
    id: `${surahNumber}:${startAyah}${endAyah !== undefined ? `-${endAyah}` : ""}`,
    surahNumber,
    startAyah,
    ...(endAyah !== undefined ? { endAyah } : {}),
  };
}

/** Shared registry: one normalized record per distinct Quran passage reference. */
export const QURAN_PASSAGES: QuranPassageReference[] = Array.from(
  new Set(QURAN_THEMES.flatMap((theme) => theme.passageIds)),
)
  .map(normalizePassageReference)
  .filter((passage): passage is QuranPassageReference => passage !== null);

export const QURAN_PASSAGES_BY_ID = Object.fromEntries(
  QURAN_PASSAGES.map((passage) => [passage.id, passage]),
) as Record<string, QuranPassageReference>;

export const QURAN_THEME_CATEGORIES_BY_ID = Object.fromEntries(
  QURAN_THEME_CATEGORIES.map((category) => [category.id, category]),
) as Record<string, QuranThemeCategory>;

/** Runtime data-integrity checks, also used by the unit tests. */
export function getQuranThemeLibraryIssues(): string[] {
  const issues: string[] = [];
  const categoryIds = new Set(QURAN_THEME_CATEGORIES.map((category) => category.id));
  const themeIds = new Set<string>();
  const passageIds = new Set(QURAN_PASSAGES.map((passage) => passage.id));

  if (QURAN_THEME_CATEGORIES.length !== 16) issues.push("A biblioteca deve conter 16 categorias.");
  if (QURAN_THEMES.length !== 64) issues.push("A biblioteca inicial deve conter 64 temas.");
  if (passageIds.size !== QURAN_PASSAGES.length)
    issues.push("Há referências canônicas duplicadas.");

  for (const theme of QURAN_THEMES) {
    if (themeIds.has(theme.id)) issues.push(`ID de tema duplicado: ${theme.id}`);
    themeIds.add(theme.id);
    if (!categoryIds.has(theme.categoryId))
      issues.push(`Categoria inexistente no tema ${theme.id}.`);
    if (theme.passageIds.length < 5 || theme.passageIds.length > 15) {
      issues.push(`Quantidade de passagens fora do intervalo esperado no tema ${theme.id}.`);
    }
    for (const reference of theme.passageIds) {
      if (!passageIds.has(reference))
        issues.push(`Referência inválida ou não normalizada: ${reference} (${theme.id}).`);
    }
  }

  const passageCountVariants = new Set(QURAN_THEMES.map((theme) => theme.passageIds.length));
  if (passageCountVariants.size < 2)
    issues.push("A quantidade de passagens deve variar entre os temas.");

  for (const category of QURAN_THEME_CATEGORIES) {
    const categoryThemes = QURAN_THEMES.filter((theme) => theme.categoryId === category.id);
    if (categoryThemes.length < 4 || categoryThemes.length > 8) {
      issues.push(`A categoria ${category.id} contém ${categoryThemes.length} temas.`);
    }
    if (new Set(categoryThemes.map((theme) => theme.passageIds.length)).size < 2) {
      issues.push(
        `A quantidade de passagens não varia entre os temas da categoria ${category.id}.`,
      );
    }
  }

  return issues;
}
