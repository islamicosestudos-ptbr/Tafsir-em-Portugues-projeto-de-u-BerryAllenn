import { defineConfig } from "vite";
import { fileURLToPath } from "node:url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";

export default defineConfig({
  server: {
    host: "0.0.0.0",
    port: 3000,
  },
  resolve: {
    // Substitui o vite-tsconfig-paths: faz "@/..." apontar para ./src
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  plugins: [
    // Tailwind v4 PRECISA vir como plugin do Vite. Sem ele, o
    // `@import "tailwindcss" source(none)` do styles.css chega cru ao
    // lightningcss e dá: Unexpected token Function("source").
    tailwindcss(),
    // Modo SPA: gera um index.html estático (sem servidor) em dist/client.
    tanstackStart({
      spa: {
        enabled: true,
        prerender: {
          outputPath: "/index.html",
          crawlLinks: false,
        },
      },
    }),
    react(),
  ],
});
